(() => {
  const STYLE_ID = 'hall-mouse-editor-2016-style';
  let ensureRaf = 0;

  function update(no, patch) {
    if (typeof window.__planerHallUpdate === 'function') window.__planerHallUpdate(no, patch);
  }

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function tableNo(el) {
    const match = String(el.querySelector(':scope > strong')?.textContent || '').match(/\d+/);
    const no = Number(match?.[0]);
    return Number.isFinite(no) ? no : null;
  }
  function dims(el) {
    const text = el.querySelector(':scope > small')?.textContent || '';
    const match = text.match(/([\d,.]+)\s*[×x]\s*([\d,.]+)/i);
    const num = v => Number(String(v).replace(',', '.'));
    return match ? { lengthM: num(match[1]), widthM: num(match[2]) } : { lengthM: 9, widthM: 3.5 };
  }
  function rotation(el) {
    const match = String(el.style.transform || '').match(/rotate\((-?[\d.]+)deg\)/i);
    return match ? Number(match[1]) : 0;
  }
  function setRotation(el, deg) {
    const current = String(el.style.transform || '');
    el.style.transform = /rotate\((-?[\d.]+)deg\)/i.test(current)
      ? current.replace(/rotate\((-?[\d.]+)deg\)/i, `rotate(${deg}deg)`)
      : `${current} rotate(${deg}deg)`.trim();
  }
  function addStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
.hall-layout-preview.edit-layout-active .hall-table{overflow:visible!important;touch-action:none;outline:1px dashed rgba(18,92,78,.35);cursor:move!important;will-change:left,top,width,height,transform;transition:none!important}
.hall-layout-preview.edit-layout-active .hall-table:hover{outline:2px solid #1d6b5b}
.hall-layout-preview.edit-layout-active .hall-table.hall-live-edit{z-index:45!important;outline:2px solid #1d6b5b!important;box-shadow:0 8px 24px rgba(0,0,0,.12)!important}
.hall-edit-handle{position:absolute!important;z-index:60!important;width:30px!important;height:30px!important;min-width:30px!important;min-height:30px!important;padding:0!important;margin:0!important;border:2px solid #164f43!important;background:#fff!important;color:#123b34!important;border-radius:50%!important;display:grid!important;place-items:center!important;font:700 18px/1 Arial,sans-serif!important;box-shadow:0 2px 8px rgba(0,0,0,.22)!important;user-select:none!important;touch-action:none!important}
.hall-resize-handle{right:-15px!important;bottom:-15px!important;cursor:nwse-resize!important}
.hall-rotate-handle{right:-46px!important;top:50%!important;transform:translateY(-50%)!important;cursor:grab!important}
.hall-rotate-handle:active{cursor:grabbing!important}
.hall-layout-toolbar-2013{position:absolute;left:12px;top:12px;z-index:70;display:flex;gap:6px}
.hall-layout-toolbar-2013 button{border:1px solid #164f43;background:#fff;color:#123b34;font-weight:700;padding:7px 10px;box-shadow:0 2px 7px rgba(0,0,0,.14);cursor:pointer}
`;
    document.head.appendChild(style);
  }

  function startLive(table, onFrame, onCommit) {
    table.classList.add('hall-live-edit');
    let frame = 0;
    let latest = null;
    const schedule = payload => {
      latest = payload;
      if (frame) return;
      frame = requestAnimationFrame(() => { frame = 0; if (latest) onFrame(latest); });
    };
    const finish = () => {
      if (frame) { cancelAnimationFrame(frame); frame = 0; }
      if (latest) onFrame(latest);
      table.classList.remove('hall-live-edit');
      if (latest) onCommit(latest);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
    };
    const move = e => schedule(e);
    const up = () => finish();
    window.addEventListener('pointermove', move, { passive: true });
    window.addEventListener('pointerup', up, { once: true });
    window.addEventListener('pointercancel', up, { once: true });
  }

  function startMove(ev, table) {
    if (!table.closest('.hall-layout-preview.edit-layout-active')) return;
    if (ev.button !== 0 || ev.target.closest('.hall-edit-handle')) return;
    const hall = table.closest('.hall-layout-preview');
    const no = tableNo(table);
    if (!hall || no == null) return;
    ev.preventDefault(); ev.stopPropagation();
    const hallRect = hall.getBoundingClientRect();
    const startX = ev.clientX, startY = ev.clientY;
    const x0 = Number.isFinite(parseFloat(table.style.left)) ? parseFloat(table.style.left) / 100 : 0.5;
    const y0 = Number.isFinite(parseFloat(table.style.top)) ? parseFloat(table.style.top) / 100 : 0.5;
    let final = { x: x0, y: y0 };
    startLive(table, e => {
      final = {
        x: clamp(x0 + (e.clientX - startX) / Math.max(1, hallRect.width), 0.02, 0.98),
        y: clamp(y0 + (e.clientY - startY) / Math.max(1, hallRect.height), 0.02, 0.98)
      };
      table.style.left = `${final.x * 100}%`;
      table.style.top = `${final.y * 100}%`;
    }, () => update(no, { x: Number(final.x.toFixed(4)), y: Number(final.y.toFixed(4)) }));
  }

  function startResize(ev, table) {
    ev.preventDefault(); ev.stopPropagation();
    const hall = table.closest('.hall-layout-preview');
    const no = tableNo(table);
    if (!hall || no == null) return;
    const hallRect = hall.getBoundingClientRect();
    const startDims = dims(table);
    const startX = ev.clientX, startY = ev.clientY;
    const radians = rotation(table) * Math.PI / 180;
    const cos = Math.cos(radians), sin = Math.sin(radians);
    const pxmX = no === 6 ? 23.2 / 14 : 16 / 9;
    const pxmY = 7 / 3.5;
    let final = { ...startDims };
    startLive(table, e => {
      const dx = e.clientX - startX, dy = e.clientY - startY;
      const localX = dx * cos + dy * sin;
      const localY = -dx * sin + dy * cos;
      final = {
        lengthM: clamp(startDims.lengthM + (localX / Math.max(1, hallRect.width) * 100) / pxmX, 1, 20),
        widthM: clamp(startDims.widthM + (localY / Math.max(1, hallRect.height) * 100) / pxmY, 1, 10)
      };
      table.style.width = `${final.lengthM * pxmX}%`;
      table.style.height = `${final.widthM * pxmY}%`;
    }, () => update(no, { lengthM: Number(final.lengthM.toFixed(2)), widthM: Number(final.widthM.toFixed(2)) }));
  }

  function startRotate(ev, table) {
    ev.preventDefault(); ev.stopPropagation();
    const no = tableNo(table);
    if (no == null) return;
    const rect = table.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const startAngle = Math.atan2(ev.clientY - cy, ev.clientX - cx) * 180 / Math.PI;
    const base = rotation(table);
    let final = base;
    startLive(table, e => {
      const angle = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
      final = (base + angle - startAngle) % 360;
      if (final < 0) final += 360;
      setRotation(table, Number(final.toFixed(1)));
    }, () => update(no, { rotationDeg: Number(final.toFixed(1)) }));
  }

  function makeHandle(className, text, title, handler, table) {
    const h = document.createElement('span');
    h.className = `hall-edit-handle ${className}`;
    h.textContent = text; h.title = title; h.setAttribute('role', 'button');
    h.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); });
    h.addEventListener('pointerdown', e => handler(e, table));
    return h;
  }
  function bindTable(table) {
    if (table.dataset.hallMouseEditorBound !== '2016') {
      table.dataset.hallMouseEditorBound = '2016';
      table.addEventListener('pointerdown', e => startMove(e, table));
    }
    if (!table.querySelector('.hall-resize-handle')) table.appendChild(makeHandle('hall-resize-handle', '↘', 'Zmień rozmiar', startResize, table));
    if (!table.querySelector('.hall-rotate-handle')) table.appendChild(makeHandle('hall-rotate-handle', '↻', 'Obróć stół', startRotate, table));
  }
  function ensureToolbar(hall) {
    if (hall.querySelector('.hall-layout-toolbar-2013')) return;
    const box = document.createElement('div'); box.className = 'hall-layout-toolbar-2013';
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'WYRÓWNAJ ROZMIARY';
    button.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      hall.querySelectorAll('.hall-table').forEach(table => {
        const no = tableNo(table); if (no != null) update(no, { lengthM: no === 6 ? 14 : 9, widthM: 3.5 });
      });
    });
    box.appendChild(button); hall.appendChild(box);
  }
  function ensure() {
    addStyle();
    document.querySelectorAll('.hall-layout-preview.edit-layout-active').forEach(hall => {
      ensureToolbar(hall); hall.querySelectorAll('.hall-table').forEach(bindTable);
    });
  }
  function schedule() {
    if (ensureRaf) return;
    ensureRaf = requestAnimationFrame(() => { ensureRaf = 0; ensure(); });
  }
  new MutationObserver(schedule).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
  window.addEventListener('load', schedule); schedule();
})();
