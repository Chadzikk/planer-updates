(() => {
  if (window.__planerPrintStyle2016) return;
  window.__planerPrintStyle2016 = true;

  const EXTRA_STYLE = `
<style id="planer-print-style-2016">
:root{--ink:#17302b;--green:#173f36;--line:#cfd9d5;--soft:#f5f8f7;--soft2:#edf3f1}
*{box-sizing:border-box}
body{font-family:Arial,Helvetica,sans-serif!important;color:var(--ink)!important;background:#fff!important;line-height:1.25!important}
h1{font-size:22px!important;margin:0 0 14px!important;color:var(--ink)!important;letter-spacing:.01em}
h2{font-size:18px!important;margin:0 0 8px!important;padding:7px 10px!important;background:var(--green)!important;color:#fff!important;border:0!important;border-radius:2px!important}
h3{font-size:13px!important;margin:12px 0 6px!important;color:var(--ink)!important;text-transform:uppercase!important;letter-spacing:.04em}
p,.meta{font-size:12px!important;margin:5px 0 9px!important}
section{break-inside:avoid-page!important;margin:0 0 14px!important}
table{width:100%!important;border-collapse:collapse!important;border:1px solid var(--line)!important;font-size:11px!important;table-layout:auto!important}
thead{display:table-header-group!important}
th{background:var(--green)!important;color:#fff!important;font-weight:700!important;text-transform:uppercase!important;letter-spacing:.02em!important;border:1px solid var(--green)!important;padding:7px 8px!important;text-align:left!important;vertical-align:middle!important}
td{border:1px solid var(--line)!important;padding:7px 8px!important;text-align:left!important;vertical-align:middle!important;background:#fff!important}
tbody tr:nth-child(even) td{background:var(--soft)!important}
td:first-child,th:first-child{font-weight:700!important}
b,strong{font-weight:700!important;color:inherit!important}
ul{margin:4px 0 8px!important;padding-left:18px!important}
li{margin:4px 0!important;font-size:11px!important}
.warn{border:1px solid #c67b24!important;background:#fff8eb!important;color:#6b4315!important;padding:8px 10px!important;font-weight:700!important}
.cols{display:grid!important;grid-template-columns:1fr 1fr!important;gap:12px!important}
.table-card{padding:0!important}
@media print{
  body{margin:0!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
  h1{page-break-after:avoid!important} h2,h3{page-break-after:avoid!important}
  tr{page-break-inside:avoid!important}
}
</style>`;

  const nativeOpen = window.open.bind(window);
  window.open = function(...args) {
    const child = nativeOpen(...args);
    if (!child || !child.document) return child;
    try {
      const doc = child.document;
      const nativeWrite = doc.write.bind(doc);
      doc.write = function(...parts) {
        let html = parts.join('');
        if (typeof html === 'string' && html.includes('window.print') && !html.includes('planer-print-style-2016')) {
          html = html.includes('</head>') ? html.replace('</head>', `${EXTRA_STYLE}</head>`) : `${EXTRA_STYLE}${html}`;
        }
        return nativeWrite(html);
      };
    } catch (_) {}
    return child;
  };
})();
