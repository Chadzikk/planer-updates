// trigger: frontend 20.1.8 build
(() => {
  const STYLE_ID = 'pipe-cut-simple-2018-style';
  const HEADER_A = 'PIERWSZE CIĘCIE';
  const HEADER_B = 'CO DALEJ Z KOŃCÓWKĄ';
  const HEADER_C = 'ODPAD';

  function norm(v) {
    return String(v || '').replace(/\s+/g, ' ').trim().toUpperCase();
  }

  function num(v) {
    return Number(String(v).replace(',', '.'));
  }

  function fmt(v) {
    return Number.isInteger(v) ? String(v) : String(Number(v.toFixed(1))).replace('.', ',');
  }

  function pipeWord(n) {
    const n10 = n % 10;
    const n100 = n % 100;
    if (n === 1) return 'rura';
    if (n10 >= 2 && n10 <= 4 && !(n100 >= 12 && n100 <= 14)) return 'rury';
    return 'rur';
  }

  function compressSequence(values) {
    const sorted = [...values].sort((a, b) => b - a);
    const groups = [];
    for (const value of sorted) {
      const last = groups[groups.length - 1];
      if (last && Math.abs(last.value - value) < 0.001) last.count += 1;
      else groups.push({ value, count: 1 });
    }
    return groups.map(g => g.count > 1 ? `${g.count} × ${fmt(g.value)}` : fmt(g.value)).join(' + ') + ' cm';
  }

  function firstCut(text) {
    const m = String(text || '').match(/Utnij\s+(\d+)\s*[×x]\s*([\d.,]+)\s*cm\s+z\s+(\d+)\s+pełnych\s+rur/i);
    if (!m) return null;
    return { pieces: Number(m[1]), length: num(m[2]), stocks: Number(m[3]) };
  }

  function branchStarts(text) {
    const source = String(text || '').replace(/\u00a0/g, ' ');
    const re = /(\d+)\s+końcówek?\s+po\s+([\d.,]+)\s*cm/gi;
    const starts = [];
    let m;
    while ((m = re.exec(source))) starts.push({ index: m.index, count: Number(m[1]) });
    if (!starts.length) return [];
    return starts.map((s, i) => ({
      count: s.count,
      text: source.slice(s.index, i + 1 < starts.length ? starts[i + 1].index : source.length)
    }));
  }

  function parseBranch(branch, firstLength) {
    const seq = [firstLength];
    const re = /utnij\s+(\d+)\s*[×x]\s*([\d.,]+)\s*cm/gi;
    let m;
    while ((m = re.exec(branch.text))) {
      const qty = Number(m[1]);
      const length = num(m[2]);
      const repeat = branch.count > 0 && qty % branch.count === 0 ? Math.max(1, qty / branch.count) : 1;
      for (let i = 0; i < repeat; i += 1) seq.push(length);
    }
    return { count: branch.count, seq };
  }

  function concisePlan(firstText, continuationText) {
    const first = firstCut(firstText);
    if (!first) {
      const cleaned = String(firstText || '').replace(/\s*→\s*zostaje[\s\S]*$/i, '').replace(/^Utnij\s+/i, '').trim();
      return cleaned ? [{ count: 1, text: cleaned }] : [];
    }

    const branches = branchStarts(continuationText).map(b => parseBranch(b, first.length));
    let used = branches.reduce((sum, b) => sum + b.count, 0);
    if (!branches.length) {
      branches.push({ count: first.stocks, seq: [first.length] });
      used = first.stocks;
    } else if (used < first.stocks) {
      branches.push({ count: first.stocks - used, seq: [first.length] });
    }

    const grouped = new Map();
    for (const branch of branches) {
      if (!branch.count) continue;
      const sorted = [...branch.seq].sort((a, b) => b - a);
      const key = sorted.map(v => v.toFixed(3)).join('|');
      const current = grouped.get(key) || { count: 0, seq: sorted };
      current.count += branch.count;
      grouped.set(key, current);
    }

    return [...grouped.values()]
      .sort((a, b) => (b.seq[0] || 0) - (a.seq[0] || 0) || b.count - a.count)
      .map(g => ({ count: g.count, text: compressSequence(g.seq) }));
  }

  function addStyle(doc) {
    if (!doc || !doc.head || doc.getElementById(STYLE_ID)) return;
    const style = doc.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      table.pipe-cut-simple-2018 th{background:#174a40!important;color:#fff!important;text-align:left!important;padding:7px 10px!important}
      table.pipe-cut-simple-2018 td{padding:8px 10px!important;vertical-align:middle!important}
      .pipe-cut-lines-2018{display:grid;gap:5px}
      .pipe-cut-line-2018{display:flex;align-items:baseline;gap:8px;line-height:1.25}
      .pipe-cut-line-2018 strong{min-width:74px;white-space:nowrap}
      .pipe-cut-line-2018 b{font-weight:700}
      @media print{
        table.pipe-cut-simple-2018{font-size:11px!important}
        table.pipe-cut-simple-2018 td{padding:6px 8px!important}
        .pipe-cut-lines-2018{gap:3px!important}
      }
    `;
    doc.head.appendChild(style);
  }

  function transformTable(table) {
    if (!table || table.dataset.pipeCutSimple2018 === '1') return false;
    const headCells = [...table.querySelectorAll('thead th')];
    if (headCells.length < 3) return false;
    const names = headCells.map(th => norm(th.textContent));
    const a = names.indexOf(HEADER_A);
    const b = names.indexOf(HEADER_B);
    const c = names.indexOf(HEADER_C);
    if (a < 0 || b < 0 || c < 0) return false;

    const mainHead = headCells[a];
    mainHead.textContent = 'PLAN CIĘCIA RURY 300 CM';
    mainHead.colSpan = 3;
    headCells[b].style.display = 'none';
    headCells[c].style.display = 'none';

    table.querySelectorAll('tbody tr').forEach(row => {
      const cells = [...row.children];
      const firstCell = cells[a];
      const continuationCell = cells[b];
      const wasteCell = cells[c];
      if (!firstCell || !continuationCell || !wasteCell) return;

      const plan = concisePlan(firstCell.textContent, continuationCell.textContent);
      if (!plan.length) return;

      const box = table.ownerDocument.createElement('div');
      box.className = 'pipe-cut-lines-2018';
      plan.forEach(item => {
        const line = table.ownerDocument.createElement('div');
        line.className = 'pipe-cut-line-2018';
        const lead = table.ownerDocument.createElement('strong');
        lead.textContent = `${item.count} ${pipeWord(item.count)}`;
        const arrow = table.ownerDocument.createElement('span');
        arrow.textContent = '→';
        const cuts = table.ownerDocument.createElement('b');
        cuts.textContent = item.text;
        line.append(lead, arrow, cuts);
        box.appendChild(line);
      });

      firstCell.textContent = '';
      firstCell.appendChild(box);
      firstCell.colSpan = 3;
      continuationCell.style.display = 'none';
      wasteCell.style.display = 'none';
    });

    table.classList.add('pipe-cut-simple-2018');
    table.dataset.pipeCutSimple2018 = '1';
    addStyle(table.ownerDocument);
    return true;
  }

  function transformDocument(doc) {
    if (!doc || !doc.querySelectorAll) return;
    addStyle(doc);
    doc.querySelectorAll('table').forEach(transformTable);
  }

  transformDocument(document);
  let raf = 0;
  new MutationObserver(() => {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      transformDocument(document);
    });
  }).observe(document.documentElement, { subtree: true, childList: true });

  const previousOpen = window.open.bind(window);
  window.open = function pipeCutOpen2018(...args) {
    const child = previousOpen(...args);
    if (!child) return child;
    let tries = 0;
    const timer = window.setInterval(() => {
      tries += 1;
      try { transformDocument(child.document); } catch (_) {}
      if (tries >= 60 || child.closed) window.clearInterval(timer);
    }, 75);
    try { child.addEventListener('load', () => transformDocument(child.document)); } catch (_) {}
    return child;
  };
})();
