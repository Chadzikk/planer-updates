(() => {
  const VERSION = '20.1.9';
  const STYLE_ID = 'planer-ui-2019-style';
  const FIXED_TOOLBAR_ID = 'planer-fixed-toolbar-2019';
  const SIMPLE_BTN_CLASS = 'planer-simple-szalowanie-2019';
  const PREVIEW_BTN_CLASS = 'planer-layout-preview-2019';
  const AUTO_FILL_BTN_CLASS = 'planer-autofill-manual-2019';

  let layoutPreviewFiles = [];
  let lastAutoGroups = [];
  let pendingPrintKind = null;
  let suppressDetailedCapture = false;

  const norm = v => String(v || '').replace(/\s+/g, ' ').trim().toUpperCase();
  const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));

  function addStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = `
#${FIXED_TOOLBAR_ID}{position:fixed;top:10px;right:12px;z-index:2147483000;display:flex;gap:6px;padding:5px;background:rgba(247,247,243,.97);border:1px solid #b9c9c5;box-shadow:0 5px 18px rgba(0,0,0,.16);backdrop-filter:blur(6px)}
#${FIXED_TOOLBAR_ID} button{min-height:42px;padding:0 14px;font-weight:800;background:#fff;border:1px solid #9fb4ae;color:#143c34;cursor:pointer}
#${FIXED_TOOLBAR_ID} button:last-child{font-size:24px;line-height:1;padding:0 13px}
.${SIMPLE_BTN_CLASS}{font-weight:900!important;background:#174a40!important;color:#fff!important}
.${PREVIEW_BTN_CLASS},.${AUTO_FILL_BTN_CLASS}{font-weight:800!important}
.pipe-cut-optimized-2019 td{padding:9px 12px!important}
.pipe-cut-optimized-2019 .pipe-cut-line-2019{display:flex;align-items:baseline;gap:12px;line-height:1.25}
.pipe-cut-optimized-2019 .pipe-cut-line-2019 strong{min-width:88px}
.planer-simple-print-2019 section{break-after:auto!important;margin:0 0 12px!important}
.planer-simple-print-2019 h2{font-size:17px!important;margin:0!important;padding:7px 10px!important;background:#174a40!important;color:#fff!important}
.planer-simple-print-2019 .simple-walls-2019{padding:8px 10px!important;border:1px solid #cad7d3!important;border-top:0!important;font-size:15px!important;font-weight:700!important}
.planer-prady-pipes-2019{margin-top:18px!important;break-before:auto!important}
.planer-prady-pipes-2019 h2{background:#174a40!important;color:#fff!important;padding:7px 10px!important}
@media(max-width:700px){#${FIXED_TOOLBAR_ID}{right:6px;top:6px}#${FIXED_TOOLBAR_ID} button{min-height:38px;padding:0 10px}}
`;
    document.head.appendChild(s);
  }

  function findButton(label) {
    const target = norm(label);
    return [...document.querySelectorAll('button,a,[role="button"]')].find(el => norm(el.textContent) === target);
  }

  function findMenuButton(edit) {
    const candidates = [...document.querySelectorAll('button,a,[role="button"]')];
    const er = edit?.getBoundingClientRect?.();
    return candidates.find(el => {
      if (el === edit) return false;
      const txt = norm(el.textContent);
      const aria = norm(el.getAttribute('aria-label'));
      const title = norm(el.getAttribute('title'));
      const menuish = txt === '☰' || txt === '≡' || txt === '☷' || aria.includes('MENU') || title.includes('MENU');
      if (!menuish) return false;
      if (!er) return true;
      const r = el.getBoundingClientRect();
      return Math.abs(r.top - er.top) < 90;
    });
  }

  function ensureFixedToolbar() {
    const edit = [...document.querySelectorAll('button,a,[role="button"]')].find(el => {
      const t = norm(el.textContent);
      return t === 'EDYTUJ UI' || t.includes('EDYTUJ UI') || t.includes('ZAMKNIJ EDYCJĘ UI');
    });
    if (!edit) return;
    const menu = findMenuButton(edit);
    let host = document.getElementById(FIXED_TOOLBAR_ID);
    if (!host) {
      host = document.createElement('div');
      host.id = FIXED_TOOLBAR_ID;
      document.body.appendChild(host);
    }
    if (!host.querySelector('[data-role="edit"]')) {
      const b = document.createElement('button');
      b.type = 'button';
      b.dataset.role = 'edit';
      b.addEventListener('click', () => edit.click());
      host.appendChild(b);
    }
    const eb = host.querySelector('[data-role="edit"]');
    eb.textContent = String(edit.textContent || 'EDYTUJ UI').trim();
    eb.disabled = !!edit.disabled;
    if (menu && !host.querySelector('[data-role="menu"]')) {
      const b = document.createElement('button');
      b.type = 'button';
      b.dataset.role = 'menu';
      b.textContent = '☰';
      b.setAttribute('aria-label', 'Menu');
      b.addEventListener('click', () => menu.click());
      host.appendChild(b);
    }
    edit.style.display = 'none';
    if (menu) menu.style.display = 'none';
  }

  function parseCuts(text) {
    const parts = String(text || '').replace(/cm/gi, '').split('+').map(v => v.trim()).filter(Boolean);
    const out = [];
    for (const part of parts) {
      let m = part.match(/^(\d+)\s*[×x]\s*([\d.,]+)$/i);
      if (m) {
        const qty = Number(m[1]);
        const len = Number(m[2].replace(',', '.'));
        if (Number.isFinite(len) && len > 0) for (let i = 0; i < qty; i++) out.push(len);
        continue;
      }
      m = part.match(/^([\d.,]+)$/);
      if (m) {
        const len = Number(m[1].replace(',', '.'));
        if (Number.isFinite(len) && len > 0) out.push(len);
      }
    }
    return out;
  }

  function fmt(v) {
    const n = Math.round(v * 10) / 10;
    return (Number.isInteger(n) ? String(n) : n.toFixed(1).replace('.', ','));
  }

  function pipeWord(n) {
    const n10 = n % 10, n100 = n % 100;
    if (n === 1) return 'rura';
    if (n10 >= 2 && n10 <= 4 && !(n100 >= 12 && n100 <= 14)) return 'rury';
    return 'rur';
  }

  function formatPattern(cuts) {
    const sorted = [...cuts].sort((a, b) => b - a);
    const groups = [];
    for (const value of sorted) {
      const last = groups[groups.length - 1];
      if (last && Math.abs(last.value - value) < 0.01) last.count++;
      else groups.push({ value, count: 1 });
    }
    return groups.map(g => g.count > 1 ? `${g.count} × ${fmt(g.value)}` : fmt(g.value)).join(' + ') + ' cm';
  }

  function packPieces(pieces, stock = 300) {
    const sorted = [...pieces].filter(v => Number.isFinite(v) && v > 0 && v <= stock + 0.01).sort((a, b) => b - a);
    const bins = [];
    for (const piece of sorted) {
      let best = -1, bestAfter = Infinity;
      for (let i = 0; i < bins.length; i++) {
        const after = stock - (bins[i].sum + piece);
        if (after >= -0.01 && after < bestAfter) { best = i; bestAfter = after; }
      }
      if (best < 0) bins.push({ cuts: [piece], sum: piece });
      else { bins[best].cuts.push(piece); bins[best].sum += piece; }
    }

    // Drugi cel po liczbie rur: koncentruj resztę w większych, użytecznych końcówkach.
    // Dzięki temu zamiast dwóch małych reszt może zostać jedna większa na następny raz.
    for (let pass = 0; pass < 120; pass++) {
      let bestMove = null;
      for (let i = 0; i < bins.length; i++) {
        for (let k = 0; k < bins[i].cuts.length; k++) {
          const p = bins[i].cuts[k];
          for (let j = 0; j < bins.length; j++) {
            if (i === j || bins[j].sum + p > stock + 0.01) continue;
            const oldRi = stock - bins[i].sum;
            const oldRj = stock - bins[j].sum;
            const newRi = oldRi + p;
            const newRj = oldRj - p;
            let gain = newRi * newRi + newRj * newRj - oldRi * oldRi - oldRj * oldRj;
            if (bins[i].cuts.length === 1) gain += 1e9;
            if (gain > 0.01 && (!bestMove || gain > bestMove.gain)) bestMove = { i, j, k, p, gain };
          }
        }
      }
      if (!bestMove) break;
      const { i, j, k, p } = bestMove;
      bins[i].cuts.splice(k, 1); bins[i].sum -= p;
      bins[j].cuts.push(p); bins[j].sum += p;
      if (!bins[i].cuts.length) bins.splice(i, 1);
    }
    bins.forEach(b => b.cuts.sort((a, b) => b - a));
    return bins;
  }

  function optimizePipeTable(table) {
    if (!table || table.dataset.pipeOptimized2019 === '1') return;
    const lines = [...table.querySelectorAll('.pipe-cut-line-2018')];
    if (!lines.length) return;
    const pieces = [];
    for (const line of lines) {
      const lead = line.querySelector('strong')?.textContent || '';
      const count = Number((lead.match(/\d+/) || [0])[0]);
      const cuts = parseCuts(line.querySelector('b')?.textContent || '');
      if (!count || !cuts.length) continue;
      for (let i = 0; i < count; i++) pieces.push(...cuts);
    }
    if (!pieces.length) return;
    const bins = packPieces(pieces, 300);
    const grouped = new Map();
    for (const bin of bins) {
      const key = bin.cuts.map(v => v.toFixed(2)).join('|');
      const g = grouped.get(key) || { count: 0, cuts: bin.cuts };
      g.count++;
      grouped.set(key, g);
    }
    const patterns = [...grouped.values()].sort((a, b) => (b.cuts[0] || 0) - (a.cuts[0] || 0) || b.count - a.count);
    const tbody = table.tBodies[0] || table.createTBody();
    tbody.textContent = '';
    for (const p of patterns) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 3;
      const line = document.createElement('div');
      line.className = 'pipe-cut-line-2019';
      const a = document.createElement('strong');
      a.textContent = `${p.count} ${pipeWord(p.count)}`;
      const arrow = document.createElement('span'); arrow.textContent = '→';
      const b = document.createElement('b'); b.textContent = formatPattern(p.cuts);
      line.append(a, arrow, b); td.appendChild(line); tr.appendChild(td); tbody.appendChild(tr);
    }
    const th = table.querySelector('thead th');
    if (th) { th.textContent = 'PLAN CIĘCIA RURY 300 CM'; th.colSpan = 3; }
    table.classList.add('pipe-cut-optimized-2019');
    table.dataset.pipeOptimized2019 = '1';
  }

  function optimizeAllPipeTables(root = document) {
    root.querySelectorAll?.('table.pipe-cut-simple-2018').forEach(optimizePipeTable);
  }

  function getPipePlanCloneHtml() {
    optimizeAllPipeTables(document);
    const table = document.querySelector('table.pipe-cut-optimized-2019, table.pipe-cut-simple-2018');
    if (!table) return '';
    const clone = table.cloneNode(true);
    clone.querySelectorAll('[style*="display: none"],[style*="display:none"]').forEach(el => el.remove());
    return clone.outerHTML;
  }

  function captureAutoGroups() {
    const order = document.querySelector('.auto-order');
    if (!order) return;
    const groups = [...order.querySelectorAll('p')].map(p => {
      const ids = String(p.textContent || '').match(/\b\d{3}\b/g) || [];
      return [...new Set(ids)];
    }).filter(g => g.length);
    if (groups.length) lastAutoGroups = groups;
  }

  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function manualFields() {
    const panel = document.querySelector('.loading-panel');
    if (!panel) return [];
    return [...panel.querySelectorAll('textarea,input[type="text"]')].filter(el => {
      if (!visible(el)) return false;
      if (el.closest('.crane-input') || el.closest('.layout-upload')) return false;
      const aria = norm(el.getAttribute('aria-label'));
      const ph = norm(el.getAttribute('placeholder'));
      return !aria.includes('NAROŻ') && !ph.includes('214+224');
    });
  }

  function prefillManual(force = false) {
    if (!lastAutoGroups.length) return false;
    const fields = manualFields();
    if (!fields.length) return false;
    if (!force && fields.some(f => String(f.value || '').trim())) return true;
    if (fields.length >= 2) {
      fields.forEach((f, i) => {
        if (i < lastAutoGroups.length && (force || !String(f.value || '').trim())) setNativeValue(f, lastAutoGroups[i].join(' + '));
      });
    } else {
      const value = lastAutoGroups.map(g => g.join(' + ')).join('\n');
      if (force || !String(fields[0].value || '').trim()) setNativeValue(fields[0], value);
    }
    return true;
  }

  function ensureManualAutofill() {
    const manual = findButton('RĘCZNA KOREKTA');
    if (!manual || !manual.classList.contains('active')) return;
    const switcher = manual.closest('.loading-mode-switch');
    if (!switcher || !lastAutoGroups.length) return;
    if (!switcher.querySelector(`.${AUTO_FILL_BTN_CLASS}`)) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = AUTO_FILL_BTN_CLASS; b.textContent = 'WCZYTAJ WYNIK AUTO';
      b.addEventListener('click', () => prefillManual(true));
      switcher.appendChild(b);
    }
    setTimeout(() => prefillManual(false), 0);
  }

  function openLayoutPreview() {
    if (!layoutPreviewFiles.length) { window.alert('Brak zapamiętanego PDF rzutu do podglądu.'); return; }
    let file = layoutPreviewFiles[0];
    if (layoutPreviewFiles.length > 1) {
      const list = layoutPreviewFiles.map((f, i) => `${i + 1}. ${f.name}`).join('\n');
      const pick = Number(window.prompt(`Który PDF otworzyć?\n${list}`, '1'));
      if (Number.isInteger(pick) && pick >= 1 && pick <= layoutPreviewFiles.length) file = layoutPreviewFiles[pick - 1];
    }
    const url = URL.createObjectURL(file);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 120000);
  }

  function ensureLayoutPreviewButtons() {
    document.querySelectorAll('.layout-upload').forEach(box => {
      if (box.querySelector(`.${PREVIEW_BTN_CLASS}`)) return;
      const b = document.createElement('button');
      b.type = 'button'; b.className = PREVIEW_BTN_CLASS; b.textContent = 'PODGLĄD PDF';
      b.disabled = !layoutPreviewFiles.length;
      b.addEventListener('click', openLayoutPreview);
      box.appendChild(b);
    });
    document.querySelectorAll(`.${PREVIEW_BTN_CLASS}`).forEach(b => { b.disabled = !layoutPreviewFiles.length; });
  }


  function stripSingleBatchLabels(doc) {
    if (!doc?.body) return;
    const all = String(doc.body.textContent || '');
    if (!/\bPARTIA\s+1\b/i.test(all) || /\bPARTIA\s+(?:[2-9]|[1-9]\d+)\b/i.test(all)) return;
    const nf = doc.defaultView?.NodeFilter?.SHOW_TEXT ?? 4;
    const walker = doc.createTreeWalker(doc.body, nf);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      const before = String(node.nodeValue || '');
      const after = before
        .replace(/PARTIA\s*1\s*•\s*/gi, '')
        .replace(/\s*•\s*PARTIA\s*1\b/gi, '')
        .replace(/\bPARTIA\s*1\b/gi, '');
      if (after !== before) node.nodeValue = after;
    });
  }

  function simplifySzalowanieWindow(doc) {
    if (!doc?.body || doc.body.dataset.simpleSzalowanie2019 === '1') return;
    const sections = [...doc.querySelectorAll('section')];
    if (!sections.length) return;
    doc.body.classList.add('planer-simple-print-2019');
    sections.forEach(section => {
      const title = section.querySelector('h2')?.textContent || 'STÓŁ';
      const walls = [...section.querySelectorAll('tbody tr')].map(tr => String(tr.cells?.[0]?.textContent || '').trim()).filter(Boolean);
      section.innerHTML = `<h2>${title}</h2><div class="simple-walls-2019">ŚCIANY: ${walls.join(' • ') || '—'}</div>`;
    });
    const h1 = doc.querySelector('h1');
    if (h1) h1.textContent = h1.textContent.replace(/SZALOWANIE.*$/i, 'SZALOWANIE');
    doc.body.dataset.simpleSzalowanie2019 = '1';
  }

  function appendPipePlanToPrady(doc) {
    if (!doc?.body || doc.body.dataset.pradyPipes2019 === '1') return;
    if (doc.querySelector('.pipe-plan-20111')) { doc.body.dataset.pradyPipes2019 = '1'; return; }
    const html = getPipePlanCloneHtml();
    if (!html) return;
    const section = doc.createElement('section');
    section.className = 'planer-prady-pipes-2019';
    section.innerHTML = `<h2>RURKI — PLAN CIĘCIA 3,00 m</h2>${html}`;
    doc.body.appendChild(section);
    doc.body.dataset.pradyPipes2019 = '1';
  }

  const previousOpen = window.open.bind(window);
  window.open = function planerOpen2019(...args) {
    const kind = pendingPrintKind;
    pendingPrintKind = null;
    const child = previousOpen(...args);
    if (!child) return child;
    let nativePrint = null;
    try {
      nativePrint = child.print.bind(child);
      child.print = () => setTimeout(() => nativePrint(), 850);
    } catch (_) {}
    let tries = 0;
    const timer = window.setInterval(() => {
      tries++;
      try {
        const title = norm(child.document?.title);
        stripSingleBatchLabels(child.document);
        if (kind === 'szal-simple' || (kind == null && title.includes('SZALOWANIE') && window.__planerSimplePending2019)) {
          simplifySzalowanieWindow(child.document);
          window.__planerSimplePending2019 = false;
        } else if (kind === 'prady' || title.endsWith('— PRĄDY') || title.includes('— PRĄDY')) {
          appendPipePlanToPrady(child.document);
        }
      } catch (_) {}
      if (tries >= 50 || child.closed) window.clearInterval(timer);
    }, 60);
    return child;
  };

  function ensureQuickPrint() {
    const actionRoots = [...document.querySelectorAll('.plan-actions,.workspace-actions')];
    actionRoots.forEach(root => {
      const buttons = [...root.querySelectorAll('button')];
      buttons.forEach(b => {
        const t = norm(b.textContent);
        if (t === 'DRUKUJ RAPORT' || t === 'DRUKUJ SZALOWANIE' || t === 'RURKI' || t === 'RURKI — CIĘCIE') b.style.display = 'none';
        if (t === 'PRĄDY — STOŁY') b.textContent = 'PRĄDY';
      });

      const current = [...root.querySelectorAll('button')];
      let simple = current.find(b => {
        const t = norm(b.textContent);
        return t === 'SZALOWANIE' || t === 'SZALOWANIE — STOŁY';
      });
      const detailed = current.find(b => norm(b.textContent) === 'SZALOWANIE SZCZEGÓŁOWE');

      if (simple) {
        simple.textContent = 'SZALOWANIE';
        simple.classList.add(SIMPLE_BTN_CLASS);
        if (!simple.dataset.planerSimpleCapture20111) {
          simple.dataset.planerSimpleCapture20111 = '1';
          simple.addEventListener('click', () => {
            pendingPrintKind = 'szal-simple';
            window.__planerSimplePending2019 = true;
          }, true);
        }
      } else if (detailed && !root.querySelector('.planer-simple-szalowanie-2019')) {
        simple = document.createElement('button');
        simple.type = 'button';
        simple.className = SIMPLE_BTN_CLASS;
        simple.textContent = 'SZALOWANIE';
        simple.disabled = detailed.disabled;
        simple.addEventListener('click', () => {
          pendingPrintKind = 'szal-simple';
          window.__planerSimplePending2019 = true;
          suppressDetailedCapture = true;
          try { detailed.click(); } finally { suppressDetailedCapture = false; }
        });
        root.insertBefore(simple, detailed);
      }

      if (detailed && !detailed.dataset.planerDetailCapture2019) {
        detailed.dataset.planerDetailCapture2019 = '1';
        detailed.addEventListener('click', () => {
          if (!suppressDetailedCapture) pendingPrintKind = 'szal-detailed';
        }, true);
      }

      const prady = [...root.querySelectorAll('button')].find(b => norm(b.textContent) === 'PRĄDY');
      if (prady && !prady.dataset.planerPradyCapture2019) {
        prady.dataset.planerPradyCapture2019 = '1';
        prady.addEventListener('click', () => { pendingPrintKind = 'prady'; }, true);
      }
    });
  }

  document.addEventListener('change', e => {
    const input = e.target instanceof HTMLInputElement ? e.target : null;
    if (!input || input.type !== 'file' || !input.closest('.layout-upload')) return;
    const pdfs = [...(input.files || [])].filter(f => f.type === 'application/pdf' || /\.pdf$/i.test(f.name));
    if (pdfs.length) layoutPreviewFiles = pdfs;
    setTimeout(ensureLayoutPreviewButtons, 0);
  }, true);

  document.addEventListener('click', e => {
    const b = e.target.closest?.('button');
    if (!b) return;
    if (norm(b.textContent) === 'RĘCZNA KOREKTA') {
      captureAutoGroups();
      setTimeout(() => { ensureManualAutofill(); ensureLayoutPreviewButtons(); }, 80);
    }
  }, true);

  function ensure() {
    addStyles();
    ensureFixedToolbar();
    ensureQuickPrint();
    optimizeAllPipeTables(document);
    ensureManualAutofill();
    ensureLayoutPreviewButtons();
  }

  let raf = 0;
  function schedule() {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; ensure(); });
  }
  new MutationObserver(schedule).observe(document.documentElement, { subtree: true, childList: true });
  window.addEventListener('load', schedule);
  schedule();
})();
