// trigger: frontend 20.1.7 build
(() => {
  const STYLE_ID = 'planer-ui-polish-2017-style';
  const PRINT_STYLE_ID = 'planer-print-compact-2017';
  const CSV_LABEL = 'CSV PROFESJONALNY';

  function addMainStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
.planer-sticky-ui-2017{
  position:sticky!important;
  top:8px!important;
  z-index:1200!important;
  width:max-content!important;
  max-width:calc(100vw - 24px)!important;
  background:rgba(247,247,243,.96)!important;
  backdrop-filter:blur(5px)!important;
  -webkit-backdrop-filter:blur(5px)!important;
  padding:4px!important;
  border:1px solid rgba(20,75,65,.16)!important;
  box-shadow:0 4px 14px rgba(0,0,0,.10)!important;
}
.planer-sticky-ui-2017 button{
  margin-top:0!important;
  margin-bottom:0!important;
}
`;
    document.head.appendChild(style);
  }

  function norm(value) {
    return String(value || '').replace(/\s+/g, ' ').trim().toUpperCase();
  }

  function removeCsvProfessional() {
    document.querySelectorAll('button,a,[role="button"]').forEach(el => {
      if (norm(el.textContent) === CSV_LABEL) {
        el.remove();
      }
    });
  }

  function commonAncestor(a, b) {
    if (!a || !b) return null;
    const seen = new Set();
    let n = a;
    while (n) { seen.add(n); n = n.parentElement; }
    n = b;
    while (n) {
      if (seen.has(n)) return n;
      n = n.parentElement;
    }
    return null;
  }

  function makeEditorSticky() {
    const edit = [...document.querySelectorAll('button,a,[role="button"]')]
      .find(el => norm(el.textContent) === 'EDYTUJ UI');
    if (!edit) return;

    const menu = [...document.querySelectorAll('button,a,[role="button"]')]
      .find(el => {
        const txt = norm(el.textContent);
        const aria = norm(el.getAttribute('aria-label'));
        const title = norm(el.getAttribute('title'));
        return txt === '☰' || txt === '≡' || txt === '☷' || aria.includes('MENU') || title.includes('MENU');
      });

    let host = menu ? commonAncestor(edit, menu) : edit.parentElement;
    if (!host) return;
    if (host === document.body || host === document.documentElement) host = edit.parentElement;
    if (!host) return;
    host.classList.add('planer-sticky-ui-2017');
  }

  function printCss() {
    return `
      body{font-family:Arial,sans-serif!important;color:#142a26!important;margin:7mm!important}
      h1{font-size:18px!important;margin:0 0 9px!important}
      section{margin:0 0 10px!important;padding:0!important;break-inside:avoid!important}
      h2{font-size:15px!important;line-height:1.15!important;margin:0!important;padding:6px 9px!important;background:#174a40!important;color:#fff!important;border:0!important}
      h3{font-size:12px!important;margin:7px 0 4px!important}
      .meta{font-size:11px!important;line-height:1.2!important;margin:0!important;padding:4px 8px!important;background:#f2f6f4!important;border-left:3px solid #174a40!important}
      table{width:100%!important;border-collapse:collapse!important;border-spacing:0!important;font-size:11px!important;margin:5px 0 8px!important}
      th{background:#174a40!important;color:#fff!important;font-size:10px!important;line-height:1.15!important;padding:5px 7px!important;border:0!important;text-align:left!important}
      td{padding:5px 7px!important;line-height:1.18!important;border:0!important;border-bottom:1px solid #d4dfdc!important;vertical-align:middle!important}
      tbody tr:nth-child(even) td{background:#f5f8f7!important}
      tbody tr:last-child td{border-bottom:0!important}
      p{margin:4px 0!important}
      .cols{gap:8px!important}
      ul{margin:2px 0!important;padding-left:17px!important}
      li{margin:2px 0!important}
      .warn{padding:5px 7px!important;margin:5px 0!important}
      @media print{section{break-after:auto!important;page-break-after:auto!important} .table-card{break-after:auto!important}}
    `;
  }

  function injectPrintStyle(win) {
    if (!win || win.closed) return;
    try {
      const doc = win.document;
      if (!doc || !doc.head || doc.getElementById(PRINT_STYLE_ID)) return;
      const style = doc.createElement('style');
      style.id = PRINT_STYLE_ID;
      style.textContent = printCss();
      doc.head.appendChild(style);
    } catch (_) {}
  }

  const nativeOpen = window.open.bind(window);
  window.open = function patchedOpen(...args) {
    const child = nativeOpen(...args);
    if (!child) return child;

    let tries = 0;
    const timer = window.setInterval(() => {
      tries += 1;
      injectPrintStyle(child);
      if (tries >= 40 || child.closed) window.clearInterval(timer);
    }, 75);

    try { child.addEventListener('load', () => injectPrintStyle(child)); } catch (_) {}
    return child;
  };

  function ensure() {
    addMainStyle();
    removeCsvProfessional();
    makeEditorSticky();
  }

  let raf = 0;
  function schedule() {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      ensure();
    });
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['class', 'style']
  });
  window.addEventListener('load', schedule);
  schedule();
})();
