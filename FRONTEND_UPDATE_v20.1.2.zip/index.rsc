2:I["8c0f216c4604",[],"Children",1]
3:I["15c18cfaeeff",[],"LayoutSegmentProvider",1]
4:I["8c0f216c4604",[],"Slot",1]
5:I["593f344dc510",[],"RedirectBoundary",1]
:HL["/assets/index-AU0YSmVk.css","style"]
0:{"__route":"route:/","__interceptionContext":null,"__layoutIds":["layout:/"],"__rootLayout":"/","page:/":"$L1","layout:/":[[[["$","link","css:/assets/index-AU0YSmVk.css",{"rel":"stylesheet","precedence":"vite-rsc/importer-resources","href":"/assets/index-AU0YSmVk.css","data-rsc-css-href":"/assets/index-AU0YSmVk.css"}],"$undefined"],["$","html",null,{"lang":"pl","children":["$","body",null,{"children":["$","$L2",null,{}]}]}]],null],"route:/":[[["$","meta",null,{"charSet":"utf-8"}],[["$","title","0",{"children":"Planer stołów i ścian"}],["$","meta","1",{"name":"description","content":"Automatyczne układanie ścian prefabrykowanych na stołach i przydział pracownikom."}],["$","link","2",{"rel":"shortcut icon","href":"/favicon.svg"}],["$","link","3",{"rel":"icon","href":"/favicon.svg"}],["$","meta","4",{"name":"codex-preview","content":"development"}]],[["$","meta","0",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]],["$","$L3",null,{"segmentMap":{"children":[]},"children":["$","$L4",null,{"id":"layout:/","parallelSlots":"$undefined","children":["$","$L5",null,{"children":["$","$L3",null,{"segmentMap":{"children":[]},"children":["$","$L4",null,{"id":"page:/"}]}]}]}]}]],"__layoutFlags":{"layout:/":"s"},"__artifactCompatibility":{"schemaVersion":1,"graphVersion":"app-route-graph:4uhn5s1wvoptc","deploymentVersion":"e0524ae5-c34d-482c-93a9-7e869b120c41","appElementsSchemaVersion":1,"rscPayloadSchemaVersion":1,"rootBoundaryId":"/","renderEpoch":null}}
6:I["6efdf509a785",[],"default",1]
1:["$","$L6",null,{"params":"$@7","searchParams":"$@8"}]
7:{}
8:{}
