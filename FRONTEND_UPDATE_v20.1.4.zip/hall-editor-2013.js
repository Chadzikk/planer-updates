(() => {
  const STYLE_ID = 'hall-mouse-editor-2013-style';
  let raf = 0;

  function update(no, patch) {
    if (typeof window.__planerHallUpdate === 'function') {
      window.__planerHallUpdate(no, patch);
    }
  }

  function tableNo(el) {
    const match = String(el.querySelector(':scope > strong')?.textContent || '').match(/\d+/);
    const no = Number(match?.[0]);
    return Number.isFinite(no) ? no : null;
  }

  function dims(el) {
    const text = el.querySelector(':scope > small')?.textContent || '';
    const match = text.match(/([\d,.]+)\s*[×x]\s*([\d,.]+)/i);
    const num = value => Number(String(value).replace(',', '.'));
    return match
      ? { lengthM: num(match[1]), widthM: num(match[2]) }
      : { lengthM: 9, widthM: 3.5 };
  }

  function rotation(el) {
    const match = String(el.style.transform || '').match(/rotate\((-?[\d.]+)deg\)/i);
    return match ? Number(match[1]) : 0;
  }

  function addStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
.hall-layout-preview.edit-layout-active .hall-table{overflow:visible!important;touch-action:none;outline:1px dashed rgba(18,92,78,.35);cursor:move!important}
.hall-layout-preview.edit-layout-active .hall-table:hover{outline:2px solid #1d6b5b}
.hall-edit-handle{position:absolute!important;z-index:40!important;width:28px!important;height:28px!important;min-width:28px!important;min-height:28px!important;padding:0!important;margin:0!important;border:2px solid #164f43!important;background:#fff!important;color:#123b34!important;border-radius:50%!important;display:grid!important;place-items:center!important;font:700 17px/1 Arial,sans-serif!important;box-shadow:0 2px 8px rgba(0,0,0,.22)!important;user-select:none!important;touch-action:none!important}
.hall-resize-handle{right:-14px!important;bottom:-14px!important;cursor:nwse-resize!important}
.hall-rotate-handle{right:-42px!important;top:50%!important;transform:translateY(-50%)!important;cursor:grab!important}
.hall-rotate-handle:active{cursor:grabbing!important}
.hall-layout-toolbar-2013{position:absolute;left:12px;top:12px;z-index:50;display:flex;gap:6px}
.hall-layout-toolbar-2013 button{border:1px solid #164f43;background:#fff;color:#123b34;font-weight:700;padding:7px 10px;box-shadow:0 2px 7px rgba(0,0,0,.14);cursor:pointer}
`;
    document.head.appendChild(style);
  }

  function cleanupWindow(move, up) {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    window.removeEventListener('pointercancel', up);
  }

  function startMove(ev, table) {
    if (!table.closest('.hall-layout-preview.edit-layout-active')) return;
    if (ev.button !== 0 || ev.target.closest('.hall-edit-handle')) return;
    const hall = table.closest('.hall-layout-preview');
    const no = tableNo(table);
    if (!hall || no == null) return;

    ev.preventDefault();
    ev.stopPropagation();

    const hallRect = hall.getBoundingClientRect();
    const startX = ev.clientX;
    const startY = ev.clientY;
    const x0 = parseFloat(table.style.left) / 100 || 0.5;
    const y0 = parseFloat(table.style.top) / 100 || 0.5;

    const move = e => update(no, {
      x: Math.max(0.02, Math.min(0.98, x0 + (e.clientX - startX) / Math.max(1, hallRect.width))),
      y: Math.max(0.02, Math.min(0.98, y0 + (e.clientY - startY) / Math.max(1, hallRect.height)))
    });
    const up = () => cleanupWindow(move, up);

    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up, { once: true });
    window.addEventListener('pointercancel', up, { once: true });
  }

  function startResize(ev, table) {
    ev.preventDefault();
    ev.stopPropagation();

    const hall = table.closest('.hall-layout-preview');
    const no = tableNo(table);
    if (!hall || no == null) return;

    const hallRect = hall.getBoundingClientRect();
    const startDims = dims(table);
    const startX = ev.clientX;
    const startY = ev.clientY;
    const radians = rotation(table) * Math.PI / 180;
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);
    const percentPerMeterX = no === 6 ? 23.2 / 14 : 16 / 9;
    const percentPerMeterY = 7 / 3.5;

    const move = e => {
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      const localX = dx * cos + dy * sin;
      const localY = -dx * sin + dy * cos;
      const lengthM = Math.max(1, Math.min(20,
        startDims.lengthM + (localX / Math.max(1, hallRect.width) * 100) / percentPerMeterX));
      const widthM = Math.max(1, Math.min(10,
        startDims.widthM + (localY / Math.max(1, hallRect.height) * 100) / percentPerMeterY));
      update(no, {
        lengthM: Number(lengthM.toFixed(2)),
        widthM: Number(widthM.toFixed(2))
      });
    };
    const up = () => cleanupWindow(move, up);

    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up, { once: true });
    window.addEventListener('pointercancel', up, { once: true });
  }

  function startRotate(ev, table) {
    ev.preventDefault();
    ev.stopPropagation();

    const no = tableNo(table);
    if (no == null) return;

    const rect = table.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const startAngle = Math.atan2(ev.clientY - cy, ev.clientX - cx) * 180 / Math.PI;
    const baseRotation = rotation(table);

    const move = e => {
      const angle = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
      let deg = (baseRotation + angle - startAngle) % 360;
      if (deg < 0) deg += 360;
      update(no, { rotationDeg: Math.round(deg) });
    };
    const up = () => cleanupWindow(move, up);

    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up, { once: true });
    window.addEventListener('pointercancel', up, { once: true });
  }

  function makeHandle(className, text, title, handler, table) {
    const handle = document.createElement('span');
    handle.className = `hall-edit-handle ${className}`;
    handle.textContent = text;
    handle.title = title;
    handle.setAttribute('role', 'button');
    handle.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
    });
    handle.addEventListener('pointerdown', e => handler(e, table));
    return handle;
  }

  function bindTable(table) {
    if (table.dataset.hallMouseEditorBound !== '1') {
      table.dataset.hallMouseEditorBound = '1';
      table.addEventListener('pointerdown', e => startMove(e, table));
    }
    if (!table.querySelector('.hall-resize-handle')) {
      table.appendChild(makeHandle('hall-resize-handle', '↘', 'Zmień rozmiar', startResize, table));
    }
    if (!table.querySelector('.hall-rotate-handle')) {
      table.appendChild(makeHandle('hall-rotate-handle', '↻', 'Obróć stół', startRotate, table));
    }
  }

  function ensureToolbar(hall) {
    if (hall.querySelector('.hall-layout-toolbar-2013')) return;
    const box = document.createElement('div');
    box.className = 'hall-layout-toolbar-2013';
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = 'WYRÓWNAJ ROZMIARY';
    button.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      hall.querySelectorAll('.hall-table').forEach(table => {
        const no = tableNo(table);
        if (no != null) update(no, { lengthM: no === 6 ? 14 : 9, widthM: 3.5 });
      });
    });
    box.appendChild(button);
    hall.appendChild(box);
  }

  function ensure() {
    addStyle();
    document.querySelectorAll('.hall-layout-preview.edit-layout-active').forEach(hall => {
      ensureToolbar(hall);
      hall.querySelectorAll('.hall-table').forEach(bindTable);
    });
  }

  function schedule() {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      ensure();
    });
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['class']
  });
  window.addEventListener('load', schedule);
  schedule();
})();
